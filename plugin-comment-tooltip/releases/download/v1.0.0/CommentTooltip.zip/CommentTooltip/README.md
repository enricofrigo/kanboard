Example of Comment tooltip plugin
=======================

This plugin add comments tooltip as older version of the kanboard.

- Same behavour of the older version moved inside a plugin
- Disabled from integrations menu 

Installation
------------

- Create a directory **CommentTooltip** under the folder **plugins**
- Copy all source files in this new directory
- Go on your local installation of Kanboard
- After the login, you should see the older comment label at the endo fo tasks board
